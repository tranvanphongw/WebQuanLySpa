<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/WebQuanLySpa/app/config/database.php';



$database = new Database();
$conn = $database->getConnection();

$sql = "SELECT DICHVU.MADV, DICHVU.TEN, DICHVU.MOTA, DICHVU.THOIGIANTHUCHIEN, DICHVU.GIATIEN, LOAIDICHVU.TENLOAI
        FROM DICHVU
        INNER JOIN LOAIDICHVU ON DICHVU.MALOAI = LOAIDICHVU.MALOAI";
$stmt = $conn->prepare($sql);
$stmt->execute();

$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    "status" => "success",
    "data" => $results
]);
?>
